function innerHtmlFUnc(para){
    const elemnt = document.getElementById(para);
    elemnt.innerHTML = "I am para and I am modified by inner Html output"


}


function documentWriteFunc(){    
    document.write("I am written using coument write")

}

function alertFunc(){
    alert("Welcome to Fullstack development");
}

function consoleLogFunc(){
    console.log("I am outputted using console log")
}