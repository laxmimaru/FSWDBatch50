
console.log("This is js opeartor demo")

var a=10;

var b = 20;

var c = a+b;

console.log("a = " + a + " b = " + b + " c = " + c);

var d = a > b;

console.log("d = " + d);

x = 11; y =20; 

var z = (x == 10) && (y ==20);

console.log(" z = " + z);


var l = (x == 10) || (y ==20);


console.log("l = " + l);

console.log("negation of l = " +(!l));

m =20;
n = "20"

console.log("value equality = " + (m == n));


console.log("value and type  equality = " + (m === n));

var k =20;
k += 1;

console.log("k = "+ k);
