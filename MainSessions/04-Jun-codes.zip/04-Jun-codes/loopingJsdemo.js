for(var count = 0;count<10;count++){
    console.log("count = "+count);
}

var edureka = 0;

while(edureka<10){
    console.log("edureka = "+edureka);
    edureka++;
}