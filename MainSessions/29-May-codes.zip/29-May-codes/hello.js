function externallyWishUser(){
    alert("Hello user!!Externally Welcome here")

}