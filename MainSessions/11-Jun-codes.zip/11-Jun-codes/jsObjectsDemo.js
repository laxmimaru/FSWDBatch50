var fruit1 = new Object();

fruit1.name="orange";
fruit1.color="orange color"
fruit1.taste = "sour"
fruit1.healthBenefit = "vitamin C"

console.log(fruit1);

console.log(fruit1.name);


