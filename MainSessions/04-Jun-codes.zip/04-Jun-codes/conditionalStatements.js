
var percentage;
var fruits = ["orange","guava","apple","chikoo"];

percentage = 50;

if(percentage>80){
    console.log("you passed in distinction");
}else{
    console.log("you did not pass in distinction");
}

var color="yellow";
switch(color){

    case "green":
        console.log("its guava");
        break;
     case "red":   
     console.log("its an apple");
     break;
     case "orange":
         console.log("its orange")
         break;
     case "chocolate":
        console.log("its a chickoo")
        break;
    default:
        console.log("its jus a random fruit");
        
}
