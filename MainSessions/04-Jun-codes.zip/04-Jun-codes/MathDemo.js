
var num1 = 3.5

var num2 = 5.4

var num3 =16;

var radius = 2;


var ceil_value = Math.ceil(num2);
var floor_value = Math.floor(num1);

console.log("ceil_value = "+ceil_value);

console.log("floor_value = "+floor_value);

console.log("sqrt of num3 = "+ Math.sqrt(num3))

console.log("2 raised to the power 3 =  "+ Math.pow(2,3));

console.log("pi value = "+Math.PI)

var area = Math.PI*Math.pow(radius,2);

console.log("area of circle = "+area);








