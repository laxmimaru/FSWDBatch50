var str1="edureka ";
var str2="Fullstack dev";


console.log("str1 = "+str1);

console.log("type of str1 = "+typeof(str1));

console.log("length = " +str1.length);

console.log("charAt 5 = "+str1.charAt(5));

//var str3 = str1.concat(" ");
//str3=str3.concat(str2);
var str3 = str1.concat(str2);
console.log("str3 = "+str3);

var spplittedstr = str3.split(" ");
console.log("spplittedstr = "+spplittedstr);

var slicedStr = str3.slice(8,12);

console.log("slicedStr = "+slicedStr);

