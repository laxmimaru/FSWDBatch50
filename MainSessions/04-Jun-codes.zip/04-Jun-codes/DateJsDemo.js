var date1 = new Date();

console.log("date1 = "+date1);

/*2022-06-05T10:20:12.939Z*/

var date2 = new Date(2022,05,05,16,0,0);

console.log("date2 = "+date2);

console.log("current date = "+date1.getDate());

console.log("year = "+date1.getFullYear());

console.log("month = "+date1.getMonth());

console.log("hours = "+date1.getHours());